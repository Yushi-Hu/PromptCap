# PromptCap
natual language guided image captioning
